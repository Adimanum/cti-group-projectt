# Неделя 3 — Обработка данных, анализ в песочнице и правило детектирования (MISP + CAPE + YARA)

**Кейс:** Tycoon2FA AiTM Phishing-as-a-Service набор

## 1. Задача

Сохранить артефакты недели 2 в MISP, отправить образец обфусцированного JavaScript в CAPE Sandbox для динамического/поведенческого анализа и написать оригинальное YARA-правило для детектирования известных паттернов набора.

## 2. Развёртывание MISP (Docker)

```bash
git clone https://github.com/MISP/misp-docker
cd misp-docker
cp template.env .env
# отредактировать .env: задать BASE_URL, пароли админа и БД
docker compose up -d
```

Интерфейс доступен по адресу `https://localhost`, вход под учётной записью администратора из `.env`.

## 3. Создание события (Event) в MISP

1. **Events → Add Event**
2. Заполнить:
   - **Event info:** `Tycoon2FA AiTM PhaaS kit — obfuscation & session-relay TTPs`
   - **Threat Level:** High
   - **Analysis:** Ongoing
   - **Distribution:** Your Organisation Only (для учебного проекта)

## 4. Импорт собранных артефактов

| Тип атрибута MISP | Значение | Category |
|---|---|---|
| `pattern-in-file` | `myscr[0-9]{6}\.js` | Payload delivery |
| `filename` | `pages-godaddy.css`, `pages-okta.css` | Payload delivery |
| `text` | Обфускация невидимыми Unicode-символами (бинарное кодирование U+FFA0 / U+3164) | Other |
| `text` | Ретрансляция учётных данных/MFA через WebSocket | Network activity |

## 5. Развёртывание CAPE Sandbox и отправка образца

```bash
git clone https://github.com/kevoreilly/CAPEv2
cd CAPEv2
sudo ./installer/cape2.sh base
sudo ./installer/cape2.sh cape
```

После установки CAPE предоставляет веб-интерфейс для отправки образцов. Порядок действий для данного кейса:

1. **Отправить** захваченную копию обфусцированного файла `myscr*.js` (или всю HTML-страницу фишинга) как задачу анализа файла/URL.
2. CAPE выполняет его в изолированной браузерной/VM-среде и фиксирует:
   - Исходящие сетевые соединения (WebSocket-ретрансляция на backend атакующего)
   - Любой динамически декодированный/выполненный через `eval` JavaScript (расшифрованный payload)
   - Поведенческие индикаторы на уровне DOM (рендеринг фейкового CAPTCHA, срабатывание anti-debugger)
3. Изучить **отчёт о поведении** и вкладку **сеть (PCAP)**, чтобы подтвердить, что паттерн AiTM-ретрансляции совпадает с задокументированным в OSINT-источниках недели 2.

## 6. Написание оригинального YARA-правила

На основе публично задокументированных паттернов (техника обфускации невидимым Unicode, паттерн имени `myscr[0-9]{6}.js`, общие имена CSS-ресурсов) — вот оригинальное правило детектирования, объединяющее эти признаки:

```yara
rule Suspected_Tycoon2FA_AiTM_Kit
{
    meta:
        description = "Detects JS/CSS artifacts consistent with Tycoon2FA-style AiTM phishing kits"
        author = "CS-2426 group project"
        reference = "Sekoia / Trustwave / Microsoft public reporting, 2025-2026"

    strings:
        $js_pattern   = /myscr[0-9]{6}\.js/ ascii wide
        $css_godaddy  = "pages-godaddy.css" ascii wide
        $css_okta     = "pages-okta.css" ascii wide
        $unicode_bit0 = "\xa0\xff" // Halfwidth Hangul Filler (U+FFA0)
        $unicode_bit1 = "\x64\x31" // Hangul Filler (U+3164)
        $ws_indicator = "new WebSocket(" ascii wide

    condition:
        (any of ($css_godaddy, $css_okta, $js_pattern)) and
        ($ws_indicator or (($unicode_bit0) and ($unicode_bit1)))
}
```

> Правило написано с нуля группой на основе публично опубликованных технических характеристик; это отправная точка для донастройки на реальных образцах, а не копия чьего-либо проприетарного правила.

## 7. Фильтрация и нормализация в MISP

- **Дедупликация**: проверять через поиск MISP перед добавлением новых атрибутов.
- **Тегирование (Taxonomies)**: `tlp:white` (данные построены на основе открытых отчётов), `misp-galaxy:tool="Tycoon2FA"`, `kill-chain:command-and-control`.
- **Correlation**: включить Correlation Engine MISP, чтобы будущие события с теми же паттернами имён файлов или индикатором WebSocket автоматически связывались.

## 8. Итог недели

Событие теперь содержит нормализованные артефакты, сгенерированный CAPE поведенческий отчёт, подтверждающий механизм AiTM-ретрансляции, и оригинальное YARA-правило, готовое к донастройке и дальнейшему threat hunting.
